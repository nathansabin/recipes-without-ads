export const setRecipes = (recipes) => ({
    type:'SET_RECIPES',
    payload: recipes
});

